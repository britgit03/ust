package com.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.model.CartItem;
import com.model.Customer;
import com.model.Product;
import com.repository.CartItemRepository;
import com.repository.ProductRepository;

@Service
@Transactional
public class CartItemService {

	@Autowired
	CartItemRepository cartItemRepository;

	@Autowired
	ProductRepository productRepo;

	public List<CartItem> listCartItems(Customer customer) {
		List<CartItem> cart = cartItemRepository.findByCustomer(customer);		
		return cart;
	}

	public Integer addProduct(Integer productId, Integer quantity, Customer customer) {
		Integer addedQuantity = 0;
		CartItem cartItem = null;
		Product product = productRepo.findById(productId).get();
		cartItem = cartItemRepository.findByCustomerAndProduct(customer, product);

		if (cartItem != null) {
			addedQuantity = cartItem.getQuantity() + quantity;
			cartItem.setQuantity(addedQuantity);
		} else {
			cartItem = new CartItem();
			cartItem.setQuantity(quantity);
			cartItem.setCustomer(customer);
			cartItem.setProduct(product);
		}
		cartItemRepository.save(cartItem);
		return addedQuantity;

	}

	public void findCartItemForDelete(Integer productId, Customer customer) {		
		CartItem cartItem = null;
		Product product = productRepo.findById(productId).get();
		cartItem = cartItemRepository.findByCustomerAndProduct(customer, product);
		if (cartItem != null) {
			cartItemRepository.deleteById(cartItem.getId());
		}
	}

	public void findCartItemForUpdate(Integer quantity, Integer productId, Customer customer) {
		CartItem cartItem = null;
		Product product = productRepo.findById(productId).get();
		cartItem = cartItemRepository.findByCustomerAndProduct(customer, product);
		if (cartItem != null) {
			CartItem cartitem = new CartItem();
			cartitem.setQuantity(quantity);			
			cartItemRepository.save(cartitem);
		}
	}

	public void removeProduct(Integer customerId, Integer productId) {
		cartItemRepository.deleteByCustomerAndProduct(productId, customerId);
	}

	public float updateQuantity(Integer productId, Integer quantity, Customer customer) {
		cartItemRepository.updateQuantity(quantity, productId, customer.getCustomerId());
		Product product = productRepo.findById(productId).get();
		float subtotal = product.getPrice() * quantity;
		return subtotal;
	}

	public void updateQuantityforCartItems(List<CartItem> cartItem) {
		cartItemRepository.saveAll(cartItem);

	}

}
