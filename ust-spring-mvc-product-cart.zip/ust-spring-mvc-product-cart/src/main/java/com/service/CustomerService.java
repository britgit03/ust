package com.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.model.Customer;
import com.repository.CartItemRepository;
import com.repository.CustomerRepository;

@Service
public class CustomerService {

	@Autowired
	CustomerRepository customerRepository;

	@Autowired
	CartItemRepository cartItemRepository;

	public void saveCustomer(Customer customerdetails) {
		customerRepository.save(customerdetails);
	}

	public List<Customer> getAllCustomer() {
		return (List<Customer>) customerRepository.findAll();
	}

	public Customer getCustomerById(Integer customerId) {
		Optional<Customer> customer = customerRepository.findById(customerId);
		return customer.get();

	}

	public void updateCustomer(Customer customerdetails) {
		customerRepository.save(customerdetails);
	}

	public void deleteCustomerById(Integer customerId) {
		customerRepository.deleteById(customerId);

	}

	public Customer getCurrentlyLoggedInCustomer(String username) {
		return customerRepository.findByCustomerName(username);

	}

}
