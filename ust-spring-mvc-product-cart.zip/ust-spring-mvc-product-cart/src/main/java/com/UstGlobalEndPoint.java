package com;

import org.springframework.boot.actuate.endpoint.annotation.Endpoint;
import org.springframework.boot.actuate.endpoint.annotation.ReadOperation;
import org.springframework.boot.actuate.endpoint.annotation.Selector;
import org.springframework.boot.actuate.endpoint.annotation.WriteOperation;

import org.springframework.stereotype.Component;


@Endpoint(id="ustglobal")
@Component
public class UstGlobalEndPoint {
	
	@ReadOperation
	public String getMessage(@Selector String companyName){
		return "Hello Welcome to " +companyName;
	}
	
	@WriteOperation
	public String getWriteMsg(String spouseName){
		return "Hi " +spouseName;
	}

}
