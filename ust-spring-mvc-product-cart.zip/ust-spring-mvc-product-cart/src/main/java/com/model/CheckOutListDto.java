package com.model;

import lombok.Data;

@Data
public class CheckOutListDto {
	private int productId;
	private String productName;
	private int quantity;
	private String customerName;
	private float total;
	

}
