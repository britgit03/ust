package com;

import org.springframework.boot.actuate.endpoint.annotation.Endpoint;
import org.springframework.boot.actuate.endpoint.annotation.ReadOperation;
import org.springframework.boot.actuate.endpoint.annotation.WriteOperation;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

@Endpoint(id="our-product-endpoint")
@Component
public class MyProductEndPoint {
	
	@ReadOperation
	public ResponseEntity<String> getMessage(){
		return new ResponseEntity<String>("Hi Britgit", HttpStatus.OK);
	}
	
	@WriteOperation
	public ResponseEntity<String> getWriteMsg(){
		return new ResponseEntity<String>("Hi Product", HttpStatus.OK);
	}


}
