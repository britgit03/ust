package com.ust.security;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.password.NoOpPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.provisioning.JdbcUserDetailsManager;



@EnableWebSecurity
public class SercurityConfigurer  extends WebSecurityConfigurerAdapter{
	
	@Autowired
	DataSource dataSource;
	
	
	@Autowired
	public void configAuthentication(AuthenticationManagerBuilder builder) throws Exception {
		builder.jdbcAuthentication().dataSource(dataSource);
	}
	
	/*@Autowired
	public void configureGlobal(AuthenticationManagerBuilder builder) throws Exception {
		builder.inMemoryAuthentication()
		.withUser("anu").password("anu@123").authorities("ROLE_ADMIN").and()
		.withUser("mohan").password("mohan@123").authorities("ROLE_USER");		
	}*/
	
	
	
	@Override
	protected void configure(HttpSecurity http) throws Exception {
		// TODO Auto-generated method stub
		http.authorizeRequests()
		//.antMatchers("/").permitAll()
		//.antMatchers("/getAllCustomer").permitAll()
		.antMatchers("/register").permitAll()
		.antMatchers("/index").hasAnyRole("USER","ADMIN")
		//.antMatchers("/getAllCustomer").hasAnyRole("USER","ADMIN")
		.antMatchers("/addCustomer").hasAnyRole("ADMIN")
		.anyRequest().authenticated().and().formLogin().loginPage("/login")
		.permitAll().and().logout().permitAll();
		
		//csrf
		http.csrf().disable();
	}
	
	@Bean
	public JdbcUserDetailsManager jdbcUserDetailsManager() {
		JdbcUserDetailsManager jdbcUserDetailsManager = new JdbcUserDetailsManager();
		//JdbcUserDetailsManager jdbc new JdbcUserDetailsManager();
		jdbcUserDetailsManager.setDataSource(dataSource);
		return jdbcUserDetailsManager;
		
	}
	
	@Bean
	public PasswordEncoder passwordEncoder() {
		return NoOpPasswordEncoder.getInstance();
	}

}
