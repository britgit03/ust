package com.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.model.Product;

public interface ProductRepository extends CrudRepository<Product, Integer>{

	public List<Product> findByProductName(String productName); 	
	//public List<Product> findByPriceGreaterThan(int productName); 
	//public List<Product> findByPriceLessThan(int productName); 
	//public List<Product> findByPriceBetween(int lowerRang,int greaterRang); 
	
	@Query("update Product p set p.quantityOnHand=?1 where p.productId=?2")
	@Modifying
	public void updateProdcutAfterAddToCart(Integer quantity, Integer productId);
}
