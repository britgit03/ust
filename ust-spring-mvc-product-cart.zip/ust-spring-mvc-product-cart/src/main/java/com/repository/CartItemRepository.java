package com.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.model.CartItem;
import com.model.Customer;
import com.model.Product;

public interface CartItemRepository extends JpaRepository<CartItem, Integer>{
	
	public List<CartItem> findByCustomer(Customer customer);
	//public List<CartItem> findByCustomer(Integer customerId);
	
	public CartItem findByCustomerAndProduct(Customer customer,Product product);
	
	@Query("update CartItem c set c.quantity=?1 where c.product.id=?2 and c.customer.id=?3")
	@Modifying
	public void updateQuantity(Integer quantity,Integer productId,Integer customerId);
		
	
	@Modifying
	@Query("delete from CartItem c where c.customer.customerId=?1 and c.product.productId=?2")	
	public void deleteByCustomerAndProduct(Integer customerId,Integer productId);
	
		
	/*@Modifying
	@Query(value="delete from cart_item c where c.customer.customer_id=?1 and c.product.product_id=?2",nativeQuery = true)	
	public void deleteByCustomerAndProduct(Integer customerId,Integer productId);*/
	
	
	/*@Modifying
	@Query("delete from Customer c where c.customerId=?1")	
	public void deleteByCustomer(Integer customerId);*/	


}
