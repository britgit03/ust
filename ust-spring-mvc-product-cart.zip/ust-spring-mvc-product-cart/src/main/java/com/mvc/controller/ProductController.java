package com.mvc.controller;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.provisioning.JdbcUserDetailsManager;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;


import com.model.Customer;
import com.model.Product;
import com.service.CustomerService;
import com.service.ProductService;



@Controller
public class ProductController {
	Logger logger = LoggerFactory.getLogger(ProductController.class);
	
	@Autowired
	ProductService productService;
	
	@Autowired
	CustomerService customerService;	
		
	
	
	@RequestMapping("/index")
	public ModelAndView welcome() {
		String username=null;		
		Object principal =SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		if(principal instanceof UserDetails) {
			username = ((UserDetails) principal).getUsername();			
		}	
		ModelAndView view =new ModelAndView();
		view.addObject("username", username);
		view.setViewName("index");
		return view;
	}
	
	@RequestMapping("/")
	public ModelAndView welcome1() {
		String username=null;		
		Object principal =SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		if(principal instanceof UserDetails) {
			username = ((UserDetails) principal).getUsername();			
		}		
		ModelAndView view =new ModelAndView();
		view.addObject("username", username);
		view.setViewName("index");
		return view;
	}
	
	
	@RequestMapping("/addProduct")
	public ModelAndView addProduct() {
		logger.info("inside the addProduct");		
		return new ModelAndView("addProduct", "command", new Product());
	}
	

	@RequestMapping("/updateQuantity")
	public String updateQuantity(Product product) {
		logger.info("inside the update product quantity details");		
		productService.updateQuantity(product);
		return "redirect:viewAllProduct";
	}
	
	@RequestMapping("/deleteCartProduct/{productId}")
	public ModelAndView deleteCartProduct(@PathVariable("productId") String productId) {
		Integer pid =new Integer(productId);
		productService.deleteProduct(pid);
		ModelAndView view = new ModelAndView();
		view.addObject("productId",productId);
		view.addObject("message", "Product with ProductId  " +productId +"  deleted successfully");
		return new ModelAndView("redirect:/viewAllProduct");
	}
	
	@RequestMapping("/saveProduct")
	public String saveProduct(Product product) {
		logger.info("inside the saveProduct");	
		productService.saveProduct(product);
		return "redirect:viewAllProduct";
	}
	
	@RequestMapping("/searchProductByIdForm")
	public ModelAndView SearchProductById() {
		return new ModelAndView("searchProductByIdForm", "command", new Product());
	}
	
	@RequestMapping("/searchProduct")
	public ModelAndView searchProduct(Product product) {
		logger.info("inside the searchProduct");
		ModelAndView modelAndView =new ModelAndView();
		modelAndView.setViewName("searchProductByIdForm");
		Integer productId = product.getProductId();
		if(productService.isProductExists(productId)) {
			Product searchProduct = productService.getProduct(productId);
			modelAndView.addObject("command", searchProduct);
			
		}else {
			modelAndView.addObject("command", new Product());
			modelAndView.addObject("message", "Product with ProductId " +productId +"doesnot exist");
			
		}
		return modelAndView;
		
	}
	
	
	@RequestMapping("/deleteProductByIdForm")
	public ModelAndView deleteProduct(Product product) {
		logger.info("inside the deleteProduct");
		ModelAndView modelAndView =new ModelAndView();
		modelAndView.setViewName("searchProductByIdForm");
		modelAndView.addObject("command", new Product());
		Integer productId = product.getProductId();
		if(productService.isProductExists(productId)) {
			productService.deleteProduct(productId);
			modelAndView.addObject("message", "Product with ProductId  " +productId +"  deleted successfully");			
		}else {
			modelAndView.addObject("message", "Product with ProductId  " +productId +"doesnot exist");			
		}
		return modelAndView;
		
	}
	
	@RequestMapping("/viewAllProduct")
	public ModelAndView viewAllProduct() {
		logger.info("inside the viewAllProduct");
		List<Product> products = productService.getProducts();		
		return new ModelAndView("viewAllProducts", "products", products);
	}
	
	@RequestMapping("editProduct/{productId}")
	public ModelAndView editProduct(@PathVariable("productId") Integer productId) {
		logger.info("inside the editCustomer method");
		ModelAndView view =new ModelAndView();
		view.setViewName("editProductForm");
		Product product = productService.getProductById(productId);
		view.addObject("command", product);
		return view;
	}
	
	
	
	@RequestMapping("/updateProductDetails")
	public String updateProductDetails(Product product) {
		logger.info("inside the updateProductDetails method");
		productService.updateProduct(product);
		return "redirect:/viewAllProduct";
	}
	
	/*@RequestMapping("/updateProduct")
	public String updateCustomer(Product product) {
		productService.updateProduct(product);
		return "redirect:/viewAllProduct";
	}*/	


}
