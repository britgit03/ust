package com.mvc.controller;


import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;


import com.ust.email.api.dto.MailResponse;
import com.ust.email.api.service.EmailService;
import com.model.CartItem;
import com.model.Customer;
import com.repository.CartItemRepository;
import com.service.CartItemService;
import com.service.CustomerService;
import com.service.ProductService;

@RestController
public class ShoppingCartController {
	Logger logger = LoggerFactory.getLogger(ShoppingCartController.class);

	@Autowired
	CartItemRepository cartItemRepository;

	@Autowired
	private CartItemService cartItemService;

	@Autowired
	private CustomerService customerService;

	@Autowired
	private ProductService productService;

	@Autowired
	private EmailService emailService;

	
	@RequestMapping("/cart/add/{pId}/{qty}/{productName}/{price}")
	public ModelAndView addProductToCart(@PathVariable("pId") Integer productId, @PathVariable("qty") Integer quantity,
			@PathVariable("productName") String productName,@PathVariable("price") Integer price,Model model) {
		logger.info("Inside the addProductToCart method");
		ModelAndView view = new ModelAndView();
		Customer customer = getCurrentUser();
		Integer cartQuantity = quantity - 1;
		Integer qty = 1;
		List<CartItem> cartItems = cartItemService.listCartItems(customer);		
		if (cartItems.size() > 10) {	
			sendEmailDetails(productId, qty, customer.getCustomerName(),productName,price);
			view.addObject("msg",
					"CartItem is full.If you add more than 10 product,the product list will send to your mail id");
		} 
		else {
			cartItemService.addProduct(productId, qty, customer);
			productService.updateProdcutAfterAddToCart(cartQuantity, productId);
			model.addAttribute("total", Total());
			view.addObject("cartItems", cartItems);
		}
		view.setViewName("cart1");
		return view;
	}

	@RequestMapping("/listCartItems")
	public ModelAndView cartProduct(Model model) {
		logger.info("Inside the cartProduct method");
		ModelAndView view = new ModelAndView();
		Customer customer = getCurrentUser();
		List<CartItem> cartItems = cartItemService.listCartItems(customer);
		if (cartItems.size() > 0) {
			model.addAttribute("total", Total());			
				view.addObject("cartItems", cartItems);
				view.setViewName("cart1");			
		} else {
			view.addObject("msg", "No item added to Your Cart.Please add the item to Cart");
			view.setViewName("empty_cart");
		}
		return view;
	}

	@RequestMapping("/cart/remove/{pid}/{quantity}/{quantityOnHand}")
	public ModelAndView removeProduct(@PathVariable("pid") Integer productId,@PathVariable("quantity") Integer quantity,@PathVariable("quantityOnHand") Integer quantityOnHand) {
		logger.info("Inside the removeProduct method");
		Integer cartQuantity =quantityOnHand+quantity;
		Customer customer = getCurrentUser();
		cartItemService.findCartItemForDelete(productId, customer);
		productService.updateProdcutAfterAddToCart(cartQuantity, productId);
		// cartItemService.removeProduct(customer.getCustomerId(),productId);
		return new ModelAndView("shopping_cart_view", "message",
				"The product has been removed from your shopping cart");
	}

	

	@RequestMapping("/cart/updateQuantityValue")
	public ModelAndView updateQuantityValue(HttpServletRequest req, HttpServletResponse res) {
		logger.info("Inside the updateQuantityValue method");		
		Customer customer = getCurrentUser();
		String[] quantityOnHand = req.getParameterValues("quantityOnHand");
		String[] quantities = req.getParameterValues("quantity");
		List<CartItem> cartItem = cartItemRepository.findByCustomer(customer);
		for (int i = 0; i < cartItem.size(); i++) {			
			cartItem.get(i).setQuantity(Integer.parseInt(quantities[i]));
			cartItemService.updateQuantityforCartItems(cartItem);
			//cartItem.get(i).getProduct().setQuantityOnHand(cartItem.get(i).getProduct().getQuantityOnHand()- cartItem.get(i).getQuantity());
		}
		return new ModelAndView("shopping_cart_view", "message", "Quantity has been updated successfully");
	}

	
		
	private MailResponse sendEmailDetails(Integer productId,Integer qty,String customerName,String productName,Integer price) {
		Map<String, Object> map = new HashMap<>();
		map.put("ProductId", productId);
		map.put("ProductName", productName);
		map.put("Quantity", qty);
		map.put("price", price);
		//map.put("subTotal", productId);
		map.put("CustomerName", customerName);
		return emailService.sendEmail(map);
	}

	private double Total() {
		double total = 0;
		Customer customer = getCurrentUser();
		List<CartItem> cartItems = cartItemService.listCartItems(customer);
		for (CartItem cartItem : cartItems) {
			total += cartItem.getQuantity() * cartItem.getProduct().getPrice();
		}
		return total;
	}
	
	private List<CartItem> updateQuantityOnHand() {		
		Customer customer = getCurrentUser();
		List<CartItem> cartItems = cartItemService.listCartItems(customer);
		for (int i = 0; i < cartItems.size(); i++) {			
			//cartItems.get(i).getProduct().setQuantityOnHand(CartItem.getProduct().getQuantityOnHand()- cartItem.getQuantity());
			cartItems.get(i).getProduct().setQuantityOnHand(cartItems.get(i).getProduct().getQuantityOnHand()- cartItems.get(i).getQuantity());
			//updateQuantityOnHand =cartItem.getProduct().getQuantityOnHand()- cartItem.getQuantity();
		}
		return cartItems;
	}

	private Customer getCurrentUser() {
		String username = null;
		Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		if (principal instanceof UserDetails) {
			username = ((UserDetails) principal).getUsername();
			System.out.println("##### username is" + username);
		}
		return customerService.getCurrentlyLoggedInCustomer(username);
	}

}
