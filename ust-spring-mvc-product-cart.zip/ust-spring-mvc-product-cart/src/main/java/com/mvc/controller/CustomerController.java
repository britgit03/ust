package com.mvc.controller;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.provisioning.JdbcUserDetailsManager;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.model.Customer;
import com.service.CustomerService;


@Controller
public class CustomerController {
	Logger logger = LoggerFactory.getLogger(CustomerController.class);
	
	@Autowired
	CustomerService customerService;
	
	@Autowired
	JdbcUserDetailsManager jdbcUserDetailsManager;
	
	@RequestMapping("/getAllCustomer")
	public ModelAndView getAllCustomer(){
		List<Customer> customer = customerService.getAllCustomer();
		return new ModelAndView("viewAllCustomer", "customer", customer);
		
	}
	
	@RequestMapping("editCustomer/{customerId}")
	public ModelAndView editCustomer(@PathVariable("customerId") Integer customerId) {
		ModelAndView view =new ModelAndView();
		view.setViewName("editCustomerForm");
		Customer customer = customerService.getCustomerById(customerId);
		view.addObject("command", customer);
		return view;
	}
	
	
	@RequestMapping("/updateCustomer")
	public String updateCustomer(Customer customer) {
		System.out.println("updateCustomer " +customer);
		logger.info("inside the updateCustomer method");
		customerService.updateCustomer(customer);
		return "redirect:/getAllCustomer";
	}
	
	@RequestMapping("deleteCustomer/{customerId}")
	public String deleteCustomer(@PathVariable("customerId") Integer customerId) {
		customerService.deleteCustomerById(customerId);
		return "redirect:/getAllCustomer";
	}
	
	@RequestMapping(value="/login", method = RequestMethod.GET)
	public String login(Model model,String error,String logout) {
	if(error!=null) {
		model.addAttribute("errorMsg", "Your User name and password are incorrect");
	}
	if(logout!=null) {
		model.addAttribute("msg", "You have been successfully logout");
	}
	return "login";
}
	
	@RequestMapping(value="/register", method = RequestMethod.GET)
	public ModelAndView login() {		
		return new ModelAndView("registration", "user", new Customer());	
	}
	
		
	@RequestMapping(value="/register", method = RequestMethod.POST)
	public ModelAndView registerUser(@ModelAttribute("user") Customer  customer) {
		logger.info("inside the registerUser method");
		List<GrantedAuthority> authorities = new ArrayList<GrantedAuthority>();
		authorities.add(new SimpleGrantedAuthority("ROLE_ADMIN"));
		
		User user = new User(customer.getCustomerName(),customer.getPassword(),authorities);
		jdbcUserDetailsManager.createUser(user);		
		customerService.saveCustomer(customer);
		return new ModelAndView("login", "message", "You have been successfully registered.Please Login");
		}

	

}
