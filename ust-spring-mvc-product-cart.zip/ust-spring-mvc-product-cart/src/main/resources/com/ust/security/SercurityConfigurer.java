package com.ust.security;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.password.NoOpPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.provisioning.JdbcUserDetailsManager;



@EnableWebSecurity
public class SercurityConfigurer  extends WebSecurityConfigurerAdapter{
	
	//@Autowired
	//private MyUserDetailService myUserDetailService;
	
	/*@Autowired
	public void configureGlobal(AuthenticationManagerBuilder builder) throws Exception {
		builder.inMemoryAuthentication()
		.withUser("britgit").password("louis").authorities("ROLE_ADMIN").and()
		.withUser("krithish").password("kumar").authorities("ROLE_USER").and()
		.withUser("abisha").password("lia").authorities("ROLE_ADMIN","ROLE_USER");
	}*/
	
	@Autowired
	DataSource dataSource;
	
	
	@Autowired
	public void configAuthentication(AuthenticationManagerBuilder builder) throws Exception {
		builder.jdbcAuthentication().dataSource(dataSource);
	}
	
	
	
	@Override
	protected void configure(HttpSecurity http) throws Exception {
		// TODO Auto-generated method stub
		http.authorizeRequests()
		//.antMatchers("/").permitAll()
		.antMatchers("/register").permitAll()
		.antMatchers("/index").hasAnyRole("USER","ADMIN")
		.antMatchers("/viewAllProduct").hasAnyRole("USER","ADMIN")
		.antMatchers("/addProduct").hasAnyRole("ADMIN")
		.antMatchers("/cart").hasAnyRole("ADMIN")
		.anyRequest().authenticated().and().formLogin().loginPage("/login")
		.permitAll().and().logout().permitAll();
		
		//csrf
		http.csrf().disable();
	}
	
	
//	protected void configure(AuthenticationManagerBuilder auth) throws Exception {
//		auth.userDetailsService(myUserDetailService);
//	}
	
	@Bean
	public JdbcUserDetailsManager jdbcUserDetailsManager() {
		JdbcUserDetailsManager jdbcUserDetailsManager = new JdbcUserDetailsManager();
		//JdbcUserDetailsManager jdbc new JdbcUserDetailsManager();
		jdbcUserDetailsManager.setDataSource(dataSource);
		return jdbcUserDetailsManager;
		
	}
	
	@Bean
	public PasswordEncoder passwordEncoder() {
		return NoOpPasswordEncoder.getInstance();
	}

}
