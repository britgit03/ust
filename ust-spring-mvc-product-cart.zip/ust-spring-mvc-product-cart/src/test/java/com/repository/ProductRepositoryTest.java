package com.repository;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase.Replace;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.annotation.Rollback;

import com.model.CartItem;
import com.model.Customer;
import com.model.Product;

@DataJpaTest
@AutoConfigureTestDatabase(replace =Replace.NONE)
@Rollback(false)
public class ProductRepositoryTest {
	
	@Autowired
	private TestEntityManager entityManager;
		
	@Autowired
	private ProductRepository productRepository;
	
	@Autowired
	private CustomerRepository customerRepository;
	
	@Test
	public void testsaveProduct() {
		Product product = new Product(101,"Bucket",10,100);	
		Product savedProduct=productRepository.save(product);
		assertNotNull(savedProduct);			
	}
	
	
	@Test
	public void testUpdateProduct() {
		Integer productId = 101;
		String productName="schoolbags";
		Product product =new Product();		
		product.setProductId(productId);
		product.setProductName(productName);
		product.setQuantityOnHand(5);
		product.setPrice(600);
		productRepository.save(product);
		//Product updatedProduct = (Product) productRepository.findByProductName(productName);
		//assertThat(updatedProduct.getProductName()).isEqualTo(productName);
		assertThat("schoolbags").isEqualTo(productName);
	}
	
		@Test
		public void testDeleteProduct() {
		Integer productId = 101;		
		boolean beforeDelete=productRepository.findById(productId).isPresent();
		productRepository.deleteById(productId);
		boolean afterDelete=productRepository.findById(productId).isPresent();
		assertTrue(beforeDelete);
		assertFalse(afterDelete);		
	}

/*@Test
public void testGetProducts() {
	List<Product> products =(List<Product>)productRepository.findAll();
	assertThat(products).size().isGreaterThan(0);
}*/

@Test
public void testGetProduct() {
	Integer productId = 51;
	Product product =productRepository.findById(productId).get();
	assertNotNull(product);
}

@Test
public void testGetProductById() {
	Integer productId = 51;
	Product product =productRepository.findById(productId).get();
	assertNotNull(product);
}
}
