package com.repository;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase.Replace;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.annotation.Rollback;

import com.model.CartItem;
import com.model.Customer;
import com.model.Product;

@DataJpaTest
@AutoConfigureTestDatabase(replace =Replace.NONE)
@Rollback(false)
public class CartItemRepositoryTest {
	
	@Autowired
	private TestEntityManager entityManager;
	
	@Autowired
	private CartItemRepository cartItemRepository;
	
	@Autowired
	private ProductRepository productRepository;
	
	@Autowired
	private CustomerRepository customerRepository;
	
	/*@Test
	public void testFindByCustomerAndProduct() {
		
		Product product = entityManager.find(Product.class, 7);
		Customer customer = entityManager.find(Customer.class, 10);
		CartItem cartItem = new CartItem();
		cartItem.setProduct(product);
		cartItem.setCustomer(customer);
		cartItem.setQuantity(1);
		//CartItem saveItem = cartItemRepository.save(cartItem);
		//assertTrue(saveItem.getId()>0);		
	}*/
	
	@Test
	public void testFindByCustomer() {
		Customer customer = new Customer();
		customer.setCustomerId(10);
		List<CartItem> cartItem = cartItemRepository.findByCustomer(customer);
		assertEquals(7, cartItem.size());
	}
	
	/*@Test
	public void testUpdateQuantity() {
		Integer quantity =2;
		CartItem cartItem =new CartItem();
		Product product = productRepository.findById(7).get();
		Customer customer = customerRepository.findByCustomerName("user12");
		cartItem = cartItemRepository.findByCustomerAndProduct(customer, product);		
		cartItem.setQuantity(quantity);
		cartItemRepository.save(cartItem);
		//assertThat(cartItem.getQuantity());
		//assertEquals(cartItem.getQuantity(), quantity);
		assertThat(cartItem.getQuantity()).isEqualTo(quantity);
	}*/
	
	@Test
	public void testdeleteByCustomerAndProduct() {
		CartItem cartItem = null;
		Integer productId = 7;
		Integer id = 2;
		//Product product = productRepository.findById(productId).get();
		//Customer customer = customerRepository.findByCustomerName("user12");
		Product product = entityManager.find(Product.class, 7);
		Customer customer = entityManager.find(Customer.class, 10);
		cartItem = cartItemRepository.findByCustomerAndProduct(customer, product);	
		System.out.println("cartItem   #####" +cartItem.getId());
		boolean beforeDelete=cartItemRepository.findById(cartItem.getId()).isPresent();
		cartItemRepository.deleteById(id);
		boolean afterDelete=cartItemRepository.findById(cartItem.getId()).isPresent();
		assertTrue(beforeDelete);
		assertFalse(afterDelete);
		
		
		
	}
	
	

}
