package com.repository;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase.Replace;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.annotation.Rollback;

import com.model.CartItem;
import com.model.Customer;
import com.model.Product;

@DataJpaTest
@AutoConfigureTestDatabase(replace =Replace.NONE)
@Rollback(false)
public class CustomerRepositoryTest {
	
	@Autowired
	private TestEntityManager entityManager;
		
		
	@Autowired
	private CustomerRepository customerRepository;
	
	@Test
	public void testSaveCustomer() {
		Customer customer = new Customer(20,"brigit123","brigit123","brigit123","brigit123@gmail.com","no12 Gandhinagar","Chennai","TN","600045",0);	
		Customer savedCustomer=customerRepository.save(customer);
		assertNotNull(savedCustomer);			
	}
	
	
	@Test
	public void testUpdateCustomer() {
		Integer customerId = 20;
		String customerName="testuser1";
		Customer customer =new Customer();		
		customer.setCustomerId(customerId);
		customer.setCustomerName(customerName);
		customer.setPassword("testuser1");
		customer.setConfirmPassword("testuser1");
		customer.setCustomerAddress("1st Street");
		customer.setCustomerCity("Trichy");
		customer.setCustomerState("Tamilnadu");
		customer.setPinCode("600005");
		customerRepository.save(customer);
		assertThat("testuser1").isEqualTo(customerName);
	}
	
		@Test
		public void testDeleteCustomerById() {
		Integer customerId = 20;		
		boolean beforeDelete=customerRepository.findById(customerId).isPresent();
		customerRepository.deleteById(customerId);
		boolean afterDelete=customerRepository.findById(customerId).isPresent();
		assertTrue(beforeDelete);
		assertFalse(afterDelete);		
	}

@Test
public void testGetAllCustomer() {
	List<Customer> customer =(List<Customer>)customerRepository.findAll();
	assertThat(customer).size().isGreaterThan(0);
}


@Test
public void testGetCustomerById() {
	Integer customerId = 10;
	Customer customer =customerRepository.findById(customerId).get();
	assertNotNull(customer);
}
}
